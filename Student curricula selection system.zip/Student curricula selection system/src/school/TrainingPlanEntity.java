package school;

public class TrainingPlanEntity {
    private int objectId;
    private String trainingProgramName;
    private String managerClass;
    private String schoolYear;
    private String refresherCourse;
    private Double credit;
    private String remark;

    public int getObjectId() {
        return objectId;
    }

    public void setObjectId(int objectId) {
        this.objectId = objectId;
    }

    public String getTrainingProgramName() {
        return trainingProgramName;
    }

    public void setTrainingProgramName(String trainingProgramName) {
        this.trainingProgramName = trainingProgramName;
    }

    public String getManagerClass() {
        return managerClass;
    }

    public void setManagerClass(String managerClass) {
        this.managerClass = managerClass;
    }

    public String getSchoolYear() {
        return schoolYear;
    }

    public void setSchoolYear(String schoolYear) {
        this.schoolYear = schoolYear;
    }

    public String getRefresherCourse() {
        return refresherCourse;
    }

    public void setRefresherCourse(String refresherCourse) {
        this.refresherCourse = refresherCourse;
    }

    public Double getCredit() {
        return credit;
    }

    public void setCredit(Double credit) {
        this.credit = credit;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TrainingPlanEntity that = (TrainingPlanEntity) o;

        if (objectId != that.objectId) return false;
        if (trainingProgramName != null ? !trainingProgramName.equals(that.trainingProgramName) : that.trainingProgramName != null)
            return false;
        if (managerClass != null ? !managerClass.equals(that.managerClass) : that.managerClass != null) return false;
        if (schoolYear != null ? !schoolYear.equals(that.schoolYear) : that.schoolYear != null) return false;
        if (refresherCourse != null ? !refresherCourse.equals(that.refresherCourse) : that.refresherCourse != null)
            return false;
        if (credit != null ? !credit.equals(that.credit) : that.credit != null) return false;
        if (remark != null ? !remark.equals(that.remark) : that.remark != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = objectId;
        result = 31 * result + (trainingProgramName != null ? trainingProgramName.hashCode() : 0);
        result = 31 * result + (managerClass != null ? managerClass.hashCode() : 0);
        result = 31 * result + (schoolYear != null ? schoolYear.hashCode() : 0);
        result = 31 * result + (refresherCourse != null ? refresherCourse.hashCode() : 0);
        result = 31 * result + (credit != null ? credit.hashCode() : 0);
        result = 31 * result + (remark != null ? remark.hashCode() : 0);
        return result;
    }
}
