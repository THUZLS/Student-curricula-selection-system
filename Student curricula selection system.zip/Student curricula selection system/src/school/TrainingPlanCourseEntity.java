package school;

public class TrainingPlanCourseEntity {
    private int objectId;
    private String courseId;
    private String courseName;
    private int trainingProgramId;
    private String courseType;
    private String trainingProgramName;
    private String bz;
    private String courseUnit;
    private String startSemester1;
    private String location1;
    private String startSemester2;
    private String location2;

    public int getObjectId() {
        return objectId;
    }

    public void setObjectId(int objectId) {
        this.objectId = objectId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getTrainingProgramId() {
        return trainingProgramId;
    }

    public void setTrainingProgramId(int trainingProgramId) {
        this.trainingProgramId = trainingProgramId;
    }

    public String getCourseType() {
        return courseType;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }

    public String getTrainingProgramName() {
        return trainingProgramName;
    }

    public void setTrainingProgramName(String trainingProgramName) {
        this.trainingProgramName = trainingProgramName;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

    public String getCourseUnit() {
        return courseUnit;
    }

    public void setCourseUnit(String courseUnit) {
        this.courseUnit = courseUnit;
    }

    public String getStartSemester1() {
        return startSemester1;
    }

    public void setStartSemester1(String startSemester1) {
        this.startSemester1 = startSemester1;
    }

    public String getLocation1() {
        return location1;
    }

    public void setLocation1(String location1) {
        this.location1 = location1;
    }

    public String getStartSemester2() {
        return startSemester2;
    }

    public void setStartSemester2(String startSemester2) {
        this.startSemester2 = startSemester2;
    }

    public String getLocation2() {
        return location2;
    }

    public void setLocation2(String location2) {
        this.location2 = location2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TrainingPlanCourseEntity that = (TrainingPlanCourseEntity) o;

        if (objectId != that.objectId) return false;
        if (trainingProgramId != that.trainingProgramId) return false;
        if (courseId != null ? !courseId.equals(that.courseId) : that.courseId != null) return false;
        if (courseName != null ? !courseName.equals(that.courseName) : that.courseName != null) return false;
        if (courseType != null ? !courseType.equals(that.courseType) : that.courseType != null) return false;
        if (trainingProgramName != null ? !trainingProgramName.equals(that.trainingProgramName) : that.trainingProgramName != null)
            return false;
        if (bz != null ? !bz.equals(that.bz) : that.bz != null) return false;
        if (courseUnit != null ? !courseUnit.equals(that.courseUnit) : that.courseUnit != null) return false;
        if (startSemester1 != null ? !startSemester1.equals(that.startSemester1) : that.startSemester1 != null)
            return false;
        if (location1 != null ? !location1.equals(that.location1) : that.location1 != null) return false;
        if (startSemester2 != null ? !startSemester2.equals(that.startSemester2) : that.startSemester2 != null)
            return false;
        if (location2 != null ? !location2.equals(that.location2) : that.location2 != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = objectId;
        result = 31 * result + (courseId != null ? courseId.hashCode() : 0);
        result = 31 * result + (courseName != null ? courseName.hashCode() : 0);
        result = 31 * result + trainingProgramId;
        result = 31 * result + (courseType != null ? courseType.hashCode() : 0);
        result = 31 * result + (trainingProgramName != null ? trainingProgramName.hashCode() : 0);
        result = 31 * result + (bz != null ? bz.hashCode() : 0);
        result = 31 * result + (courseUnit != null ? courseUnit.hashCode() : 0);
        result = 31 * result + (startSemester1 != null ? startSemester1.hashCode() : 0);
        result = 31 * result + (location1 != null ? location1.hashCode() : 0);
        result = 31 * result + (startSemester2 != null ? startSemester2.hashCode() : 0);
        result = 31 * result + (location2 != null ? location2.hashCode() : 0);
        return result;
    }
}
