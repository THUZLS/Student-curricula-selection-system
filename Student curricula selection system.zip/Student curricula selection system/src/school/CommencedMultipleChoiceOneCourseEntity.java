package school;

public class CommencedMultipleChoiceOneCourseEntity {
    private int objectId;
    private String classId;
    private String courseId;
    private String courseName;
    private Integer multiChoiceOne;
    private String courseProfessional;

    public int getObjectId() {
        return objectId;
    }

    public void setObjectId(int objectId) {
        this.objectId = objectId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Integer getMultiChoiceOne() {
        return multiChoiceOne;
    }

    public void setMultiChoiceOne(Integer multiChoiceOne) {
        this.multiChoiceOne = multiChoiceOne;
    }

    public String getCourseProfessional() {
        return courseProfessional;
    }

    public void setCourseProfessional(String courseProfessional) {
        this.courseProfessional = courseProfessional;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CommencedMultipleChoiceOneCourseEntity that = (CommencedMultipleChoiceOneCourseEntity) o;

        if (objectId != that.objectId) return false;
        if (classId != null ? !classId.equals(that.classId) : that.classId != null) return false;
        if (courseId != null ? !courseId.equals(that.courseId) : that.courseId != null) return false;
        if (courseName != null ? !courseName.equals(that.courseName) : that.courseName != null) return false;
        if (multiChoiceOne != null ? !multiChoiceOne.equals(that.multiChoiceOne) : that.multiChoiceOne != null)
            return false;
        if (courseProfessional != null ? !courseProfessional.equals(that.courseProfessional) : that.courseProfessional != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = objectId;
        result = 31 * result + (classId != null ? classId.hashCode() : 0);
        result = 31 * result + (courseId != null ? courseId.hashCode() : 0);
        result = 31 * result + (courseName != null ? courseName.hashCode() : 0);
        result = 31 * result + (multiChoiceOne != null ? multiChoiceOne.hashCode() : 0);
        result = 31 * result + (courseProfessional != null ? courseProfessional.hashCode() : 0);
        return result;
    }
}
