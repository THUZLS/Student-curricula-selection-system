package school;

public class CourseTimePlanEntity {
    private int objectId;
    private String classId;
    private String courseName;
    private String startStopWeek;
    private String week;
    private String classTime;
    private String room;
    private String location;
    private String year;
    private Integer isExperimental;

    public int getObjectId() {
        return objectId;
    }

    public void setObjectId(int objectId) {
        this.objectId = objectId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getStartStopWeek() {
        return startStopWeek;
    }

    public void setStartStopWeek(String startStopWeek) {
        this.startStopWeek = startStopWeek;
    }

    public String getWeek() {
        return week;
    }

    public void setWeek(String week) {
        this.week = week;
    }

    public String getClassTime() {
        return classTime;
    }

    public void setClassTime(String classTime) {
        this.classTime = classTime;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Integer getIsExperimental() {
        return isExperimental;
    }

    public void setIsExperimental(Integer isExperimental) {
        this.isExperimental = isExperimental;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseTimePlanEntity that = (CourseTimePlanEntity) o;

        if (objectId != that.objectId) return false;
        if (classId != null ? !classId.equals(that.classId) : that.classId != null) return false;
        if (courseName != null ? !courseName.equals(that.courseName) : that.courseName != null) return false;
        if (startStopWeek != null ? !startStopWeek.equals(that.startStopWeek) : that.startStopWeek != null)
            return false;
        if (week != null ? !week.equals(that.week) : that.week != null) return false;
        if (classTime != null ? !classTime.equals(that.classTime) : that.classTime != null) return false;
        if (room != null ? !room.equals(that.room) : that.room != null) return false;
        if (location != null ? !location.equals(that.location) : that.location != null) return false;
        if (year != null ? !year.equals(that.year) : that.year != null) return false;
        if (isExperimental != null ? !isExperimental.equals(that.isExperimental) : that.isExperimental != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = objectId;
        result = 31 * result + (classId != null ? classId.hashCode() : 0);
        result = 31 * result + (courseName != null ? courseName.hashCode() : 0);
        result = 31 * result + (startStopWeek != null ? startStopWeek.hashCode() : 0);
        result = 31 * result + (week != null ? week.hashCode() : 0);
        result = 31 * result + (classTime != null ? classTime.hashCode() : 0);
        result = 31 * result + (room != null ? room.hashCode() : 0);
        result = 31 * result + (location != null ? location.hashCode() : 0);
        result = 31 * result + (year != null ? year.hashCode() : 0);
        result = 31 * result + (isExperimental != null ? isExperimental.hashCode() : 0);
        return result;
    }
}
