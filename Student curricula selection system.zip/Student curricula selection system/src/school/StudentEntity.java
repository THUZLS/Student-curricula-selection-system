package school;

import java.sql.Date;

public class StudentEntity {
    private String studentId;
    private String major;
    private String name;
    private String majorType;
    private Date matriculationDate;

    public StudentEntity() {
    }

    public StudentEntity(String studentId, String major, String name, String majorType, Date matriculationDate) {

        this.studentId = studentId;
        this.major = major;
        this.name = name;
        this.majorType = majorType;
        this.matriculationDate = matriculationDate;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMajorType() {
        return majorType;
    }

    public void setMajorType(String majorType) {
        this.majorType = majorType;
    }

    public Date getMatriculationDate() {
        return matriculationDate;
    }

    public void setMatriculationDate(Date matriculationDate) {
        this.matriculationDate = matriculationDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StudentEntity that = (StudentEntity) o;

        if (studentId != null ? !studentId.equals(that.studentId) : that.studentId != null) return false;
        if (major != null ? !major.equals(that.major) : that.major != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (majorType != null ? !majorType.equals(that.majorType) : that.majorType != null) return false;
        if (matriculationDate != null ? !matriculationDate.equals(that.matriculationDate) : that.matriculationDate != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = studentId != null ? studentId.hashCode() : 0;
        result = 31 * result + (major != null ? major.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (majorType != null ? majorType.hashCode() : 0);
        result = 31 * result + (matriculationDate != null ? matriculationDate.hashCode() : 0);
        return result;
    }
}
