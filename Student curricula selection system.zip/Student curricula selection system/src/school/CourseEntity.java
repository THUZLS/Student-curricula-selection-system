package school;

public class CourseEntity {
    private int objectId;
    private String courseId;
    private String courseName;
    private String theoryHours;
    private String testHours;
    private Double credit;
    private String writer;
    private String objectivesAndrequirements;
    private String coursesInfo;
    private String keyAndDifficult;
    private String teachingMaterials;
    private String mainContentsAndHoursAllocation;

    public int getObjectId() {
        return objectId;
    }

    public void setObjectId(int objectId) {
        this.objectId = objectId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getTheoryHours() {
        return theoryHours;
    }

    public void setTheoryHours(String theoryHours) {
        this.theoryHours = theoryHours;
    }

    public String getTestHours() {
        return testHours;
    }

    public void setTestHours(String testHours) {
        this.testHours = testHours;
    }

    public Double getCredit() {
        return credit;
    }

    public void setCredit(Double credit) {
        this.credit = credit;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getObjectivesAndrequirements() {
        return objectivesAndrequirements;
    }

    public void setObjectivesAndrequirements(String objectivesAndrequirements) {
        this.objectivesAndrequirements = objectivesAndrequirements;
    }

    public String getCoursesInfo() {
        return coursesInfo;
    }

    public void setCoursesInfo(String coursesInfo) {
        this.coursesInfo = coursesInfo;
    }

    public String getKeyAndDifficult() {
        return keyAndDifficult;
    }

    public void setKeyAndDifficult(String keyAndDifficult) {
        this.keyAndDifficult = keyAndDifficult;
    }

    public String getTeachingMaterials() {
        return teachingMaterials;
    }

    public void setTeachingMaterials(String teachingMaterials) {
        this.teachingMaterials = teachingMaterials;
    }

    public String getMainContentsAndHoursAllocation() {
        return mainContentsAndHoursAllocation;
    }

    public void setMainContentsAndHoursAllocation(String mainContentsAndHoursAllocation) {
        this.mainContentsAndHoursAllocation = mainContentsAndHoursAllocation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseEntity that = (CourseEntity) o;

        if (objectId != that.objectId) return false;
        if (courseId != null ? !courseId.equals(that.courseId) : that.courseId != null) return false;
        if (courseName != null ? !courseName.equals(that.courseName) : that.courseName != null) return false;
        if (theoryHours != null ? !theoryHours.equals(that.theoryHours) : that.theoryHours != null) return false;
        if (testHours != null ? !testHours.equals(that.testHours) : that.testHours != null) return false;
        if (credit != null ? !credit.equals(that.credit) : that.credit != null) return false;
        if (writer != null ? !writer.equals(that.writer) : that.writer != null) return false;
        if (objectivesAndrequirements != null ? !objectivesAndrequirements.equals(that.objectivesAndrequirements) : that.objectivesAndrequirements != null)
            return false;
        if (coursesInfo != null ? !coursesInfo.equals(that.coursesInfo) : that.coursesInfo != null) return false;
        if (keyAndDifficult != null ? !keyAndDifficult.equals(that.keyAndDifficult) : that.keyAndDifficult != null)
            return false;
        if (teachingMaterials != null ? !teachingMaterials.equals(that.teachingMaterials) : that.teachingMaterials != null)
            return false;
        if (mainContentsAndHoursAllocation != null ? !mainContentsAndHoursAllocation.equals(that.mainContentsAndHoursAllocation) : that.mainContentsAndHoursAllocation != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = objectId;
        result = 31 * result + (courseId != null ? courseId.hashCode() : 0);
        result = 31 * result + (courseName != null ? courseName.hashCode() : 0);
        result = 31 * result + (theoryHours != null ? theoryHours.hashCode() : 0);
        result = 31 * result + (testHours != null ? testHours.hashCode() : 0);
        result = 31 * result + (credit != null ? credit.hashCode() : 0);
        result = 31 * result + (writer != null ? writer.hashCode() : 0);
        result = 31 * result + (objectivesAndrequirements != null ? objectivesAndrequirements.hashCode() : 0);
        result = 31 * result + (coursesInfo != null ? coursesInfo.hashCode() : 0);
        result = 31 * result + (keyAndDifficult != null ? keyAndDifficult.hashCode() : 0);
        result = 31 * result + (teachingMaterials != null ? teachingMaterials.hashCode() : 0);
        result = 31 * result + (mainContentsAndHoursAllocation != null ? mainContentsAndHoursAllocation.hashCode() : 0);
        return result;
    }
}
