package school;

import java.sql.Date;

public class CoursePlanEntity {
    private int objectId;
    private String classId;
    private String courseId;
    private int maxNumber;
    private int allowMultipleChoice;
    private String courseName;
    private String teacherName;
    private String teacherName2;
    private String expelimentTeacher;
    private String expelimentTeacher2;
    private String expelimentTeacher3;
    private String detailLocation;
    private String timeAndRoom;
    private Date electiveStartTime;
    private Date electiveEndTime;
    private Date backCourseEndTime;
    private String optionalProfessional;
    private Integer isDelete;
    private String newSchoolYear;
    private String experimental;

    public int getObjectId() {
        return objectId;
    }

    public void setObjectId(int objectId) {
        this.objectId = objectId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public int getMaxNumber() {
        return maxNumber;
    }

    public void setMaxNumber(int maxNumber) {
        this.maxNumber = maxNumber;
    }

    public int getAllowMultipleChoice() {
        return allowMultipleChoice;
    }

    public void setAllowMultipleChoice(int allowMultipleChoice) {
        this.allowMultipleChoice = allowMultipleChoice;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherName2() {
        return teacherName2;
    }

    public void setTeacherName2(String teacherName2) {
        this.teacherName2 = teacherName2;
    }

    public String getExpelimentTeacher() {
        return expelimentTeacher;
    }

    public void setExpelimentTeacher(String expelimentTeacher) {
        this.expelimentTeacher = expelimentTeacher;
    }

    public String getExpelimentTeacher2() {
        return expelimentTeacher2;
    }

    public void setExpelimentTeacher2(String expelimentTeacher2) {
        this.expelimentTeacher2 = expelimentTeacher2;
    }

    public String getExpelimentTeacher3() {
        return expelimentTeacher3;
    }

    public void setExpelimentTeacher3(String expelimentTeacher3) {
        this.expelimentTeacher3 = expelimentTeacher3;
    }

    public String getDetailLocation() {
        return detailLocation;
    }

    public void setDetailLocation(String detailLocation) {
        this.detailLocation = detailLocation;
    }

    public String getTimeAndRoom() {
        return timeAndRoom;
    }

    public void setTimeAndRoom(String timeAndRoom) {
        this.timeAndRoom = timeAndRoom;
    }

    public Date getElectiveStartTime() {
        return electiveStartTime;
    }

    public void setElectiveStartTime(Date electiveStartTime) {
        this.electiveStartTime = electiveStartTime;
    }

    public Date getElectiveEndTime() {
        return electiveEndTime;
    }

    public void setElectiveEndTime(Date electiveEndTime) {
        this.electiveEndTime = electiveEndTime;
    }

    public Date getBackCourseEndTime() {
        return backCourseEndTime;
    }

    public void setBackCourseEndTime(Date backCourseEndTime) {
        this.backCourseEndTime = backCourseEndTime;
    }

    public String getOptionalProfessional() {
        return optionalProfessional;
    }

    public void setOptionalProfessional(String optionalProfessional) {
        this.optionalProfessional = optionalProfessional;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public String getNewSchoolYear() {
        return newSchoolYear;
    }

    public void setNewSchoolYear(String newSchoolYear) {
        this.newSchoolYear = newSchoolYear;
    }

    public String getExperimental() {
        return experimental;
    }

    public void setExperimental(String experimental) {
        this.experimental = experimental;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CoursePlanEntity that = (CoursePlanEntity) o;

        if (objectId != that.objectId) return false;
        if (maxNumber != that.maxNumber) return false;
        if (allowMultipleChoice != that.allowMultipleChoice) return false;
        if (classId != null ? !classId.equals(that.classId) : that.classId != null) return false;
        if (courseId != null ? !courseId.equals(that.courseId) : that.courseId != null) return false;
        if (courseName != null ? !courseName.equals(that.courseName) : that.courseName != null) return false;
        if (teacherName != null ? !teacherName.equals(that.teacherName) : that.teacherName != null) return false;
        if (teacherName2 != null ? !teacherName2.equals(that.teacherName2) : that.teacherName2 != null) return false;
        if (expelimentTeacher != null ? !expelimentTeacher.equals(that.expelimentTeacher) : that.expelimentTeacher != null)
            return false;
        if (expelimentTeacher2 != null ? !expelimentTeacher2.equals(that.expelimentTeacher2) : that.expelimentTeacher2 != null)
            return false;
        if (expelimentTeacher3 != null ? !expelimentTeacher3.equals(that.expelimentTeacher3) : that.expelimentTeacher3 != null)
            return false;
        if (detailLocation != null ? !detailLocation.equals(that.detailLocation) : that.detailLocation != null)
            return false;
        if (timeAndRoom != null ? !timeAndRoom.equals(that.timeAndRoom) : that.timeAndRoom != null) return false;
        if (electiveStartTime != null ? !electiveStartTime.equals(that.electiveStartTime) : that.electiveStartTime != null)
            return false;
        if (electiveEndTime != null ? !electiveEndTime.equals(that.electiveEndTime) : that.electiveEndTime != null)
            return false;
        if (backCourseEndTime != null ? !backCourseEndTime.equals(that.backCourseEndTime) : that.backCourseEndTime != null)
            return false;
        if (optionalProfessional != null ? !optionalProfessional.equals(that.optionalProfessional) : that.optionalProfessional != null)
            return false;
        if (isDelete != null ? !isDelete.equals(that.isDelete) : that.isDelete != null) return false;
        if (newSchoolYear != null ? !newSchoolYear.equals(that.newSchoolYear) : that.newSchoolYear != null)
            return false;
        if (experimental != null ? !experimental.equals(that.experimental) : that.experimental != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = objectId;
        result = 31 * result + (classId != null ? classId.hashCode() : 0);
        result = 31 * result + (courseId != null ? courseId.hashCode() : 0);
        result = 31 * result + maxNumber;
        result = 31 * result + (int) allowMultipleChoice;
        result = 31 * result + (courseName != null ? courseName.hashCode() : 0);
        result = 31 * result + (teacherName != null ? teacherName.hashCode() : 0);
        result = 31 * result + (teacherName2 != null ? teacherName2.hashCode() : 0);
        result = 31 * result + (expelimentTeacher != null ? expelimentTeacher.hashCode() : 0);
        result = 31 * result + (expelimentTeacher2 != null ? expelimentTeacher2.hashCode() : 0);
        result = 31 * result + (expelimentTeacher3 != null ? expelimentTeacher3.hashCode() : 0);
        result = 31 * result + (detailLocation != null ? detailLocation.hashCode() : 0);
        result = 31 * result + (timeAndRoom != null ? timeAndRoom.hashCode() : 0);
        result = 31 * result + (electiveStartTime != null ? electiveStartTime.hashCode() : 0);
        result = 31 * result + (electiveEndTime != null ? electiveEndTime.hashCode() : 0);
        result = 31 * result + (backCourseEndTime != null ? backCourseEndTime.hashCode() : 0);
        result = 31 * result + (optionalProfessional != null ? optionalProfessional.hashCode() : 0);
        result = 31 * result + (isDelete != null ? isDelete.hashCode() : 0);
        result = 31 * result + (newSchoolYear != null ? newSchoolYear.hashCode() : 0);
        result = 31 * result + (experimental != null ? experimental.hashCode() : 0);
        return result;
    }
}
