-- DROP INDEX CLASS_DETAIL_FK;
-- DROP INDEX ElectiveStudent_FK;
-- DROP INDEX ElectiveStudent2_FK;
-- DROP INDEX MULTIPLE_CLASS_DETAIL_FK;
-- 1、课程详细信息表  CLASS_DETAIL（没有被外键约束）
-- 2、选课总表  TOTAL_CLASS
-- 3、多选一课程表  MUL_CHOICE_CLASS
-- 4、学生信息表  STUDENT_INFO（这个没有被外键约束，提前插入也可以）
-- 5、选课  ElectiveStudent

DROP TABLE TOTAL_CLASS; --对应CoursePlan和CourseTimePlan
DROP TABLE STUDENT_INFO; --对应student    ✔
DROP TABLE MUL_CHOICE_CLASS; --对应CommencedMulCOC和MCOC
DROP TABLE ELECTIVE_STUDENT; --生成，不用导入
DROP TABLE COURSE_SCH; --对应Course   ✔

CREATE TABLE COURSE_SCH
(
  CourseID                       NVARCHAR2(50) PRIMARY KEY NOT NULL,
  CourseName                     NVARCHAR2(50)             NOT NULL,
  TheoryHours                    NVARCHAR2(10)             NOT NULL,
  TestHours                      NVARCHAR2(10)             NOT NULL,
  Credit                         FLOAT(50)                 NOT NULL,
  writer                         NVARCHAR2(400)            NOT NULL,
  ObjectivesAndrequirements      CLOB                      NOT NULL,
  CoursesInfo                    CLOB                      NOT NULL,
  KeyAndDifficult                CLOB                      NOT NULL,
  TeachingMaterials              CLOB                      NOT NULL,
  MainContentsAndHoursAllocation CLOB                      NOT NULL
);

CREATE TABLE ELECTIVE_STUDENT
(
  IdESStuCouCla NVARCHAR2(50) PRIMARY KEY NOT NULL,
  StudentID     NVARCHAR2(50)             NOT NULL,
  CourseID      NVARCHAR2(50)             NOT NULL,
  ClassID       NVARCHAR2(50)             NOT NULL,
  MajorType     NVARCHAR2(50)             NOT NULL,
  Year          NVARCHAR2(50)             NOT NULL,
  IsPriority    INT
);

CREATE TABLE MUL_CHOICE_CLASS
(
  IdCourseClass      INT PRIMARY KEY NOT NULL,
  CourseID           NVARCHAR2(50)   NOT NULL,
  ClassID            NVARCHAR2(50)   NOT NULL,
  CourseName         NVARCHAR2(50)   NOT NULL,
  MultiChoiceOne     NVARCHAR2(50)   NOT NULL,
  CourseProfessional NVARCHAR2(200)  NOT NULL
);
CREATE TABLE STUDENT_INFO
(
  StudentID         NVARCHAR2(50) PRIMARY KEY NOT NULL,
  Name              NVARCHAR2(50)             NOT NULL,
  Major             NVARCHAR2(50)             NOT NULL,
  MajorType         NVARCHAR2(50)             NOT NULL,
  MatriculationDate DATE
);
CREATE TABLE TOTAL_CLASS
(
  IdCourseClass        INT PRIMARY KEY NOT NULL,
  CourseID             NVARCHAR2(50)   NOT NULL,
  ClassID              NVARCHAR2(50)   NOT NULL,
  CourseName           NVARCHAR2(50)   NOT NULL,
  MaxNumber            INT             NOT NULL,
  AllowMultipleChoice  INT             NOT NULL,
  --   Credit               FLOAT(50)       NOT NULL,
  TeacherName          NVARCHAR2(50)   NOT NULL,
  TeacherName2         NVARCHAR2(50),
  ExpelimentTeacher    NVARCHAR2(50),
  ExpelimentTeacher2   NVARCHAR2(50),
  ExpelimentTeacher3   NVARCHAR2(50),
  StartStopWeek        NVARCHAR2(50)   NOT NULL,
  Week                 NVARCHAR2(50)   NOT NULL,
  ClassTime            NVARCHAR2(50)   NOT NULL,
  Room                 NVARCHAR2(50)   NOT NULL,
  Location             NVARCHAR2(50)   NOT NULL,
  Year                 NVARCHAR2(50)   NOT NULL,
  ElectiveStartTime    DATE,
  ElectiveEndTime      DATE,
  BackCourseEndTime    DATE,
  OptionalProfessional NVARCHAR2(50)   NOT NULL,
  ISExperimental       INT             NOT NULL,
  IsDelete             INT             NOT NULL
);

-- CREATE INDEX CLASS_DETAIL_FK
--   ON TOTAL_CLASS (CourseName);
-- CREATE INDEX MULTIPLE_CLASS_DETAIL_FK
--   ON MUL_CHOICE_CLASS (CourseName);
-- CREATE INDEX ElectiveStudent_FK
--   ON ELECTIVE_STUDENT (StudentID);
-- CREATE INDEX ElectiveStudent2_FK
--   ON ELECTIVE_STUDENT (CourseID, ClassID);
