DROP TABLE TrainingPlanCourse
DROP TABLE TrainingPlan
DROP TABLE Student
DROP TABLE MultipleChoiceOneCourse
DROP TABLE CoursePlan
DROP TABLE CommencedMultipleChoiceOneCourse
DROP TABLE Course
DROP TABLE CourseTimePlan
DROP TABLE ElectiveStudent

CREATE TABLE CommencedMultipleChoiceOneCourse
(
  ObjectID           INT PRIMARY KEY NOT NULL,
  ClassID            NVARCHAR(50),
  CourseID           NVARCHAR(50),
  CourseName         NVARCHAR(50),
  MultiChoiceOne     INT,
  CourseProfessional NVARCHAR(200)
);
CREATE TABLE Course
(
  ObjectID                       INT PRIMARY KEY NOT NULL,
  CourseID                       NVARCHAR(50)    NOT NULL,
  CourseName                     NVARCHAR(50)    NOT NULL,
  TheoryHours                    NVARCHAR(10),
  TestHours                      NVARCHAR(10),
  Credit                         FLOAT,
  writer                         NVARCHAR(4000),
  ObjectivesAndrequirements      TEXT,
  CoursesInfo                    TEXT,
  KeyAndDifficult                TEXT,
  TeachingMaterials              TEXT,
  MainContentsAndHoursAllocation TEXT
);
CREATE TABLE CoursePlan
(
  ObjectID             INT PRIMARY KEY NOT NULL,
  ClassID              NVARCHAR(50)    NOT NULL,
  CourseID             NVARCHAR(50)    NOT NULL,
  MaxNumber            INT             NOT NULL,
  AllowMultipleChoice  INT             NOT NULL,
  CourseName           NVARCHAR(50),
  TeacherName          NVARCHAR(50),
  TeacherName2         NVARCHAR(50),
  ExpelimentTeacher    NVARCHAR(50),
  ExpelimentTeacher2   NVARCHAR(50),
  ExpelimentTeacher3   NVARCHAR(50),
  DetailLocation       NVARCHAR(50),
  TimeAndRoom          NVARCHAR(500),
  ElectiveStartTime    DATE,
  ElectiveEndTime      DATE,
  BackCourseEndTime    DATE,
  OptionalProfessional NVARCHAR(50),
  IsDelete             INT,
  NewSchoolYear        NVARCHAR(50),
  Experimental         NVARCHAR(100)
);
CREATE TABLE CourseTimePlan
(
  ObjectID       INT PRIMARY KEY NOT NULL,
  ClassID        NVARCHAR(50)    NOT NULL,
  CourseName     NVARCHAR(50),
  StartStopWeek  NVARCHAR(50),
  Week           NVARCHAR(50),
  ClassTime      NVARCHAR(50),
  Room           NVARCHAR(50),
  Location       NVARCHAR(50),
  Year           NVARCHAR(50),
  ISExperimental INT
);
CREATE TABLE ElectiveStudent
(
  ObjectID    INT PRIMARY KEY NOT NULL,
  ClassID     NVARCHAR(50),
  CourseID    NVARCHAR(50),
  StudentID   NVARCHAR(50)    NOT NULL,
  StudentName NVARCHAR(50),
  Year        NVARCHAR(50)
);
CREATE TABLE MultipleChoiceOneCourse
(
  ObjectID           INT PRIMARY KEY NOT NULL,
  CourseID           NVARCHAR(50),
  CourseName         NVARCHAR(50),
  MultiChoiceOne     NVARCHAR(50),
  CourseProfessional NVARCHAR(200)
);
CREATE TABLE Student
(
  StudentID         NVARCHAR(50) PRIMARY KEY NOT NULL,
  Major             NVARCHAR(50)             NOT NULL,
  Name              NVARCHAR(50)             NOT NULL,
  MajorType         NVARCHAR(50)             NOT NULL,
  MatriculationDate DATE
);
CREATE TABLE TrainingPlan
(
  ObjectID            INT PRIMARY KEY NOT NULL,
  TrainingProgramName NVARCHAR(50),
  ManagerClass        NVARCHAR(2000),
  SchoolYear          NVARCHAR(50),
  RefresherCourse     NVARCHAR(200),
  Credit              FLOAT,
  Remark              NVARCHAR(200)
);
CREATE TABLE TrainingPlanCourse
(
  ObjectID            INT PRIMARY KEY NOT NULL,
  CourseID            NVARCHAR(50)    NOT NULL,
  CourseName          NVARCHAR(50)    NOT NULL,
  TrainingProgramID   INT             NOT NULL,
  CourseType          NVARCHAR(2000),
  TrainingProgramName NVARCHAR(50),
  BZ                  NVARCHAR(500),
  CourseUnit          NVARCHAR(50),
  StartSemester1      NVARCHAR(50),
  Location1           NVARCHAR(50),
  StartSemester2      NVARCHAR(50),
  Location2           NVARCHAR(50)
);


