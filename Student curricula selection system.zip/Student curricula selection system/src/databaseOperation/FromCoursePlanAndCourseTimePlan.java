package databaseOperation;

import mysystem.TotalClassEntity;
import org.hibernate.query.Query;

import java.util.List;

import static sessionFactory.OperateSession.mySession;
import static sessionFactory.OperateSession.schoolSession;

public class FromCoursePlanAndCourseTimePlan extends AbstractEntities {
    @Override
    public FromCoursePlanAndCourseTimePlan importData() {
        return this;
    }

    public void toTotalClass() {
        this.examToEntity();
    }

    @Override
    protected void setToEntityName() {
        toEntityName = "TotalClass";
    }

    @Override
    protected void setFromEntityName() {
        fromEntityName = "CoursePlan And CourseTimePlan";
    }

    @Override
    protected void importConstructor() {
        Query query = schoolSession.createQuery(
                "select d.courseId,c.classId,c.courseName,d.maxNumber,d.allowMultipleChoice,d.teacherName,d.teacherName2,d.expelimentTeacher,d.expelimentTeacher2,d.expelimentTeacher3,c.startStopWeek,c.week,c.classTime,c.room,c.location,c.year,d.electiveStartTime,d.electiveEndTime,d.backCourseEndTime,d.optionalProfessional,c.isExperimental,d.isDelete from CourseTimePlanEntity c inner join CoursePlanEntity d on (c.classId=d.classId and c.courseName=d.courseName) "
        );
        List fromEntity = query.list();
//        System.out.println(fromEntity.size());
        for (int i = 0; i < fromEntity.size(); i++) {
            Object[] objs = (Object[]) fromEntity.get(i);
            TotalClassEntity totalClassEntity = new TotalClassEntity(objs);
//            totalClassEntity.setIdcourseclass(i);//主键自增
            mySession.save(totalClassEntity);
        }
    }
}
