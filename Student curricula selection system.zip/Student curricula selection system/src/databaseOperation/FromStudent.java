package databaseOperation;

import mysystem.StudentInfoEntity;
import school.StudentEntity;

import java.util.List;

import static sessionFactory.OperateSession.mySession;

public class FromStudent extends AbstractEntities {

    @Override
    public FromStudent importData() {
        return this;
    }

    public void toStudentInfo(){
        this.examToEntity();
    }

    @Override
    protected void setFromEntityName() {
        fromEntityName = "Student";
    }

    @Override
    protected void setToEntityName() {
        toEntityName = "StudentInfo";
    }

    @Override
    protected void importConstructor() {
//        importStudentInfo();
//        System.out.println("导入StudentInfoEntity...");
//        Query schoolSessionQuery = schoolSession.createQuery(
//                " from StudentEntity ");
        List<StudentEntity> studentEntities = schoolSessionQuery.list();

        for (StudentEntity student : studentEntities) {
            StudentInfoEntity studentInfoEntity = new StudentInfoEntity(
                    student.getStudentId(),
                    student.getName(),
                    student.getMajor(),
                    student.getMajorType(),
                    student.getMatriculationDate());
            mySession.save(studentInfoEntity);
        }
//        System.out.println("导入StudentInfoEntity完毕");
    }
}
