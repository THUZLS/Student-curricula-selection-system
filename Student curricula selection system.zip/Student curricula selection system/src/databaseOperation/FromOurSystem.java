package databaseOperation;


import school.*;

import java.util.List;

import static sessionFactory.OperateSession.mySession;
import static sessionFactory.OperateSession.schoolSession;
import static webOP.WebOp.getStudentName;

public class FromOurSystem extends AbstractEntities {
    @Override
    public FromOurSystem importData() {
        return this;
    }

    public void toSchoolSystem() {
        this.examToEntity2();
    }

    @Override
    protected void setToEntityName() {
        toEntityName = "school.ElectiveStudent";
    }

    @Override
    protected void setFromEntityName() {
        fromEntityName = "mysystem.ElectiveStudent";
    }

    @Override
    protected void importConstructor() {
        List<mysystem.ElectiveStudentEntity> fromEntitys = mySession.createQuery(
                    "from mysystem.ElectiveStudentEntity e where e.ispriority=2").list();
        int i = 0;
        for (mysystem.ElectiveStudentEntity element : fromEntitys) {
            ElectiveStudentEntity electiveStudentEntity = new ElectiveStudentEntity(
                    ++i,
                    element.getClassid(),
                    element.getCourseid(),
                    element.getStudentid(),
                    getStudentName(element.getStudentid()),
                    element.getYear()
            );
            schoolSession.save(electiveStudentEntity);
        }
    }
}