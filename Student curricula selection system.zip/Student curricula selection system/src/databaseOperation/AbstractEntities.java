package databaseOperation;

import org.hibernate.query.Query;

import javax.swing.*;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

import static sessionFactory.OperateSession.mySession;
import static sessionFactory.OperateSession.schoolSession;

abstract class AbstractEntities {

    String toEntityName;
    String fromEntityName;

    private String Information;

    protected AbstractEntities() {
        setFromEntityName();
        setToEntityName();
    }

    protected abstract void setFromEntityName();

    private String getFromEntityName() {
        return fromEntityName;
    }

    protected abstract void setToEntityName();

    private String getToEntityName() {
        return toEntityName;
    }

    protected abstract void importConstructor();

    protected void examToEntity() {
        System.out.println("检测到管理员【导入】操作:");
        System.out.println("数据源:" + getFromEntityName() + "    目标:" + getToEntityName());
        Query mySessionQuery = mySession.createQuery(
                String.format("from %sEntity", getToEntityName()));
        List lists = mySessionQuery.list();
        if (!lists.isEmpty()) {
            Information = getToEntityName() + "表格记录状态:在" + getToEntityName() + "表中发现已有" + lists.size() + "行(条)数据(记录)，导入前需要清空此表，确认请点击Yes，取消请点击No!";
            System.out.println(Information);
//            Scanner str = new Scanner(System.in);
//            int a = str.nextInt();
            int a = 0;
//            int a = JOptionPane.showConfirmDialog(null, Information, "表格删除提示", JOptionPane.YES_NO_OPTION);
            if (a == 0) {
                for (Object element : lists) {
                    mySession.delete(element);
                }
                System.out.println("已删除原来数据!");
                importEntity();
            } else {
                Information = "导入已取消!";
                System.out.println(Information);
            }
        } else {
            Information = "表格为空";
            System.out.println(getToEntityName() + "表格记录状态:" + "空");
            importEntity();
        }
    }

    protected void examToEntity2() {
        System.out.println("检测到管理员【导入】操作:");
        System.out.println("数据源:" + getFromEntityName() + "    目标:" + getToEntityName());
        Query schoolSessionQuery = schoolSession.createQuery(
                String.format("from %sEntity", getToEntityName()));
        List lists = schoolSessionQuery.list();
        if (!lists.isEmpty()) {
            Information = getToEntityName() + "表格记录状态:在" + getToEntityName() + "表中发现已有" + lists.size() + "行(条)数据(记录)，导入前需要清空此表，确认请点击Yes，取消请点击No!";
            System.out.println(Information);
//            Scanner str = new Scanner(System.in);
//            int a = str.nextInt();
            int a = 0;
//            int a = JOptionPane.showConfirmDialog(null, Information, "表格删除提示", JOptionPane.YES_NO_OPTION);
            if (0 == a) {
                for (Object element : lists) {
                    schoolSession.delete(element);
                }
                System.out.println("已删除原来数据!");
                importEntity2();
            } else {
                Information = "导入已取消!";
                System.out.println(Information);
            }
        } else {
            Information = "表格为空";
            System.out.println(getToEntityName() + "表格记录状态:" + "空");
            importEntity2();
        }
    }

    protected abstract AbstractEntities importData();

    protected Query schoolSessionQuery;
    protected Query mySessionQuery;

    private void importEntity() {
        System.out.println("从" + getFromEntityName() + "导入到" + getToEntityName() + "... ...");
        if (!getFromEntityName().contains("And"))
            schoolSessionQuery = schoolSession.createQuery(
                    String.format("from %sEntity", getFromEntityName()));
        importConstructor();
        System.out.println("导入到" + getToEntityName() + "完毕!\n");
    }

    private void importEntity2() {
        System.out.println("从" + getFromEntityName() + "导入到" + getToEntityName() + "... ...");
        importConstructor();
        System.out.println("导入到" + getToEntityName() + "完毕!\n");
    }

    protected static void exportData() {


    }

}

