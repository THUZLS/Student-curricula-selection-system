package databaseOperation;

import mysystem.CourseSchEntity;
import school.CourseEntity;

import java.util.List;

import static sessionFactory.OperateSession.mySession;

public class FromCourse extends AbstractEntities {
    @Override
    public FromCourse importData() {
        return this;
    }

    public void toCourseSch() {this.examToEntity();}

    @Override
    protected void setToEntityName() {
        toEntityName = "CourseSch";
    }

    @Override
    protected void setFromEntityName() {
        fromEntityName = "Course";
    }

    @Override
    protected void importConstructor() {
        List<CourseEntity> fromEntitys = schoolSessionQuery.list();
        for (CourseEntity courseElement : fromEntitys) {
            CourseSchEntity courseSchEntity = new CourseSchEntity(
                    courseElement.getCourseId(),
                    courseElement.getCourseName(),
                    courseElement.getTheoryHours(),
                    courseElement.getTestHours(),
                    courseElement.getCredit(),
                    courseElement.getWriter(),
                    courseElement.getObjectivesAndrequirements(),
                    courseElement.getCoursesInfo(),
                    courseElement.getKeyAndDifficult(),
                    courseElement.getTeachingMaterials(),
                    courseElement.getMainContentsAndHoursAllocation()
            );
            mySession.save(courseSchEntity);
        }
    }
}

