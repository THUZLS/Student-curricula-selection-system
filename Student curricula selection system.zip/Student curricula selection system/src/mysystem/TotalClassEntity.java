package mysystem;

import java.sql.Date;

public class TotalClassEntity {
    private int idcourseclass;//未在构造函数中赋值，主键自增
    private String courseid;
    private String classid;
    private String coursename;
    private int maxnumber;
    private int allowmultiplechoice;
    //    private double credit;
    private String teachername;
    private String teachername2;
    private String expelimentteacher;
    private String expelimentteacher2;
    private String expelimentteacher3;
    private String startstopweek;
    private String week;
    private String classtime;
    private String room;
    private String location;
    private String year;
    private Date electivestarttime;
    private Date electiveendtime;
    private Date backcourseendtime;
    private String optionalprofessional;
    private int isexperimental;
    private int isdelete;


    public TotalClassEntity(Object[] objs) {
        this.courseid = (String) objs[0];
        this.classid = (String) objs[1];
        this.coursename = (String) objs[2];
        this.maxnumber = (int) objs[3];
        this.allowmultiplechoice = (int) objs[4];
        this.teachername = (String) objs[5];
        this.teachername2 = (String) objs[6];
        this.expelimentteacher = (String) objs[7];
        this.expelimentteacher2 = (String) objs[8];
        this.expelimentteacher3 = (String) objs[9];
        this.startstopweek = (String) objs[10];
        this.week = (String) objs[11];
        this.classtime = (String) objs[12];
        this.room = (String) objs[13];
        this.location = (String) objs[14];
        this.year = (String) objs[15];
        this.electivestarttime = (Date) objs[16];
        this.electiveendtime = (Date) objs[17];
        this.backcourseendtime = (Date) objs[18];
        this.optionalprofessional = (String) objs[19];
        this.isexperimental = (int) objs[20];
        this.isdelete = (int) objs[21];
    }


    public TotalClassEntity() {
    }

    public int getIdcourseclass() {
        return idcourseclass;
    }

    public void setIdcourseclass(int idcourseclass) {
        this.idcourseclass = idcourseclass;
    }

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public int getMaxnumber() {
        return maxnumber;
    }

    public void setMaxnumber(int maxnumber) {
        this.maxnumber = maxnumber;
    }

    public int getAllowmultiplechoice() {
        return allowmultiplechoice;
    }

    public void setAllowmultiplechoice(int allowmultiplechoice) {
        this.allowmultiplechoice = allowmultiplechoice;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public String getTeachername2() {
        return teachername2;
    }

    public void setTeachername2(String teachername2) {
        this.teachername2 = teachername2;
    }

    public String getExpelimentteacher() {
        return expelimentteacher;
    }

    public void setExpelimentteacher(String expelimentteacher) {
        this.expelimentteacher = expelimentteacher;
    }

    public String getExpelimentteacher2() {
        return expelimentteacher2;
    }

    public void setExpelimentteacher2(String expelimentteacher2) {
        this.expelimentteacher2 = expelimentteacher2;
    }

    public String getExpelimentteacher3() {
        return expelimentteacher3;
    }

    public void setExpelimentteacher3(String expelimentteacher3) {
        this.expelimentteacher3 = expelimentteacher3;
    }

    public String getStartstopweek() {
        return startstopweek;
    }

    public void setStartstopweek(String startstopweek) {
        this.startstopweek = startstopweek;
    }

    public String getWeek() {
        return week;
    }

    public void setWeek(String week) {
        this.week = week;
    }

    public String getClasstime() {
        return classtime;
    }

    public void setClasstime(String classtime) {
        this.classtime = classtime;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Date getElectivestarttime() {
        return electivestarttime;
    }

    public void setElectivestarttime(Date electivestarttime) {
        this.electivestarttime = electivestarttime;
    }

    public Date getElectiveendtime() {
        return electiveendtime;
    }

    public void setElectiveendtime(Date electiveendtime) {
        this.electiveendtime = electiveendtime;
    }

    public Date getBackcourseendtime() {
        return backcourseendtime;
    }

    public void setBackcourseendtime(Date backcourseendtime) {
        this.backcourseendtime = backcourseendtime;
    }

    public String getOptionalprofessional() {
        return optionalprofessional;
    }

    public void setOptionalprofessional(String optionalprofessional) {
        this.optionalprofessional = optionalprofessional;
    }

    public int getIsexperimental() {
        return isexperimental;
    }

    public void setIsexperimental(int isexperimental) {
        this.isexperimental = isexperimental;
    }

    public int getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(int isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TotalClassEntity)) return false;

        TotalClassEntity that = (TotalClassEntity) o;

        if (idcourseclass != that.idcourseclass) return false;
        if (maxnumber != that.maxnumber) return false;
        if (allowmultiplechoice != that.allowmultiplechoice) return false;
        if (isexperimental != that.isexperimental) return false;
        if (isdelete != that.isdelete) return false;
        if (courseid != null ? !courseid.equals(that.courseid) : that.courseid != null) return false;
        if (classid != null ? !classid.equals(that.classid) : that.classid != null) return false;
        if (coursename != null ? !coursename.equals(that.coursename) : that.coursename != null) return false;
        if (teachername != null ? !teachername.equals(that.teachername) : that.teachername != null) return false;
        if (teachername2 != null ? !teachername2.equals(that.teachername2) : that.teachername2 != null) return false;
        if (expelimentteacher != null ? !expelimentteacher.equals(that.expelimentteacher) : that.expelimentteacher != null)
            return false;
        if (expelimentteacher2 != null ? !expelimentteacher2.equals(that.expelimentteacher2) : that.expelimentteacher2 != null)
            return false;
        if (expelimentteacher3 != null ? !expelimentteacher3.equals(that.expelimentteacher3) : that.expelimentteacher3 != null)
            return false;
        if (startstopweek != null ? !startstopweek.equals(that.startstopweek) : that.startstopweek != null)
            return false;
        if (week != null ? !week.equals(that.week) : that.week != null) return false;
        if (classtime != null ? !classtime.equals(that.classtime) : that.classtime != null) return false;
        if (room != null ? !room.equals(that.room) : that.room != null) return false;
        if (location != null ? !location.equals(that.location) : that.location != null) return false;
        if (year != null ? !year.equals(that.year) : that.year != null) return false;
        if (electivestarttime != null ? !electivestarttime.equals(that.electivestarttime) : that.electivestarttime != null)
            return false;
        if (electiveendtime != null ? !electiveendtime.equals(that.electiveendtime) : that.electiveendtime != null)
            return false;
        if (backcourseendtime != null ? !backcourseendtime.equals(that.backcourseendtime) : that.backcourseendtime != null)
            return false;
        return optionalprofessional != null ? optionalprofessional.equals(that.optionalprofessional) : that.optionalprofessional == null;
    }

    @Override
    public int hashCode() {
        int result = (int) (idcourseclass ^ (idcourseclass >>> 32));
        result = 31 * result + (courseid != null ? courseid.hashCode() : 0);
        result = 31 * result + (classid != null ? classid.hashCode() : 0);
        result = 31 * result + (coursename != null ? coursename.hashCode() : 0);
        result = 31 * result + (int) (maxnumber ^ (maxnumber >>> 32));
        result = 31 * result + (int) (allowmultiplechoice ^ (allowmultiplechoice >>> 32));
        result = 31 * result + (teachername != null ? teachername.hashCode() : 0);
        result = 31 * result + (teachername2 != null ? teachername2.hashCode() : 0);
        result = 31 * result + (expelimentteacher != null ? expelimentteacher.hashCode() : 0);
        result = 31 * result + (expelimentteacher2 != null ? expelimentteacher2.hashCode() : 0);
        result = 31 * result + (expelimentteacher3 != null ? expelimentteacher3.hashCode() : 0);
        result = 31 * result + (startstopweek != null ? startstopweek.hashCode() : 0);
        result = 31 * result + (week != null ? week.hashCode() : 0);
        result = 31 * result + (classtime != null ? classtime.hashCode() : 0);
        result = 31 * result + (room != null ? room.hashCode() : 0);
        result = 31 * result + (location != null ? location.hashCode() : 0);
        result = 31 * result + (year != null ? year.hashCode() : 0);
        result = 31 * result + (electivestarttime != null ? electivestarttime.hashCode() : 0);
        result = 31 * result + (electiveendtime != null ? electiveendtime.hashCode() : 0);
        result = 31 * result + (backcourseendtime != null ? backcourseendtime.hashCode() : 0);
        result = 31 * result + (optionalprofessional != null ? optionalprofessional.hashCode() : 0);
        result = 31 * result + (int) (isexperimental ^ (isexperimental >>> 32));
        result = 31 * result + (int) (isdelete ^ (isdelete >>> 32));
        return result;
    }
}


//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//
//        TotalClassEntity that = (TotalClassEntity) o;
//
//        if (idcourseclass != that.idcourseclass) return false;
//        if (maxnumber != that.maxnumber) return false;
//        if (allowmultiplechoice != that.allowmultiplechoice) return false;
//        if (isexperimental != that.isexperimental) return false;
//        if (isdelete != that.isdelete) return false;
//        if (courseid != null ? !courseid.equals(that.courseid) : that.courseid != null) return false;
//        if (classid != null ? !classid.equals(that.classid) : that.classid != null) return false;
//        if (coursename != null ? !coursename.equals(that.coursename) : that.coursename != null) return false;
//        if (teachername != null ? !teachername.equals(that.teachername) : that.teachername != null) return false;
//        if (teachername2 != null ? !teachername2.equals(that.teachername2) : that.teachername2 != null) return false;
//        if (expelimentteacher != null ? !expelimentteacher.equals(that.expelimentteacher) : that.expelimentteacher != null)
//            return false;
//        if (expelimentteacher2 != null ? !expelimentteacher2.equals(that.expelimentteacher2) : that.expelimentteacher2 != null)
//            return false;
//        if (expelimentteacher3 != null ? !expelimentteacher3.equals(that.expelimentteacher3) : that.expelimentteacher3 != null)
//            return false;
//        if (startstopweek != null ? !startstopweek.equals(that.startstopweek) : that.startstopweek != null)
//            return false;
//        if (week != null ? !week.equals(that.week) : that.week != null) return false;
//        if (classtime != null ? !classtime.equals(that.classtime) : that.classtime != null) return false;
//        if (room != null ? !room.equals(that.room) : that.room != null) return false;
//        if (location != null ? !location.equals(that.location) : that.location != null) return false;
//        if (year != null ? !year.equals(that.year) : that.year != null) return false;
//        if (electivestarttime != null ? !electivestarttime.equals(that.electivestarttime) : that.electivestarttime != null)
//            return false;
//        if (electiveendtime != null ? !electiveendtime.equals(that.electiveendtime) : that.electiveendtime != null)
//            return false;
//        if (backcourseendtime != null ? !backcourseendtime.equals(that.backcourseendtime) : that.backcourseendtime != null)
//            return false;
//        if (optionalprofessional != null ? !optionalprofessional.equals(that.optionalprofessional) : that.optionalprofessional != null)
//            return false;
//
//        return true;
//    }
//
//    @Override
//    public int hashCode() {
//        int result;
//        int temp;
//        result = (int) (idcourseclass ^ (idcourseclass >>> 32));
//        result = 31 * result + (courseid != null ? courseid.hashCode() : 0);
//        result = 31 * result + (classid != null ? classid.hashCode() : 0);
//        result = 31 * result + (coursename != null ? coursename.hashCode() : 0);
//        result = 31 * result + (int) (maxnumber ^ (maxnumber >>> 32));
//        result = 31 * result + (int) (allowmultiplechoice ^ (allowmultiplechoice >>> 32));
//        result = 31 * result + (teachername != null ? teachername.hashCode() : 0);
//        result = 31 * result + (teachername2 != null ? teachername2.hashCode() : 0);
//        result = 31 * result + (expelimentteacher != null ? expelimentteacher.hashCode() : 0);
//        result = 31 * result + (expelimentteacher2 != null ? expelimentteacher2.hashCode() : 0);
//        result = 31 * result + (expelimentteacher3 != null ? expelimentteacher3.hashCode() : 0);
//        result = 31 * result + (startstopweek != null ? startstopweek.hashCode() : 0);
//        result = 31 * result + (week != null ? week.hashCode() : 0);
//        result = 31 * result + (classtime != null ? classtime.hashCode() : 0);
//        result = 31 * result + (room != null ? room.hashCode() : 0);
//        result = 31 * result + (location != null ? location.hashCode() : 0);
//        result = 31 * result + (year != null ? year.hashCode() : 0);
//        result = 31 * result + (electivestarttime != null ? electivestarttime.hashCode() : 0);
//        result = 31 * result + (electiveendtime != null ? electiveendtime.hashCode() : 0);
//        result = 31 * result + (backcourseendtime != null ? backcourseendtime.hashCode() : 0);
//        result = 31 * result + (optionalprofessional != null ? optionalprofessional.hashCode() : 0);
//        result = 31 * result + (int) (isexperimental ^ (isexperimental >>> 32));
//        result = 31 * result + (int) (isdelete ^ (isdelete >>> 32));
//        return result;
//    }
//}
