package mysystem;

public class  CourseSchEntity {
    private String courseid;
    private String coursename;
    private String theoryhours;
    private String testhours;
    private double credit;
    private String writer;
    private String objectivesandrequirements;
    private String coursesinfo;
    private String keyanddifficult;
    private String teachingmaterials;
    private String maincontentsandhoursallocation;

    public CourseSchEntity(String courseid, String coursename, String theoryhours, String testhours, double credit, String writer, String objectivesandrequirements, String coursesinfo, String keyanddifficult, String teachingmaterials, String maincontentsandhoursallocation) {
        this.courseid = courseid;
        this.coursename = coursename;
        this.theoryhours = theoryhours;
        this.testhours = testhours;
        this.credit = credit;
        this.writer = writer;
        this.objectivesandrequirements = objectivesandrequirements;
        this.coursesinfo = coursesinfo;
        this.keyanddifficult = keyanddifficult;
        this.teachingmaterials = teachingmaterials;
        this.maincontentsandhoursallocation = maincontentsandhoursallocation;
    }

    public CourseSchEntity() {

    }

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public String getTheoryhours() {
        return theoryhours;
    }

    public void setTheoryhours(String theoryhours) {
        this.theoryhours = theoryhours;
    }

    public String getTesthours() {
        return testhours;
    }

    public void setTesthours(String testhours) {
        this.testhours = testhours;
    }

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getObjectivesandrequirements() {
        return objectivesandrequirements;
    }

    public void setObjectivesandrequirements(String objectivesandrequirements) {
        this.objectivesandrequirements = objectivesandrequirements;
    }

    public String getCoursesinfo() {
        return coursesinfo;
    }

    public void setCoursesinfo(String coursesinfo) {
        this.coursesinfo = coursesinfo;
    }

    public String getKeyanddifficult() {
        return keyanddifficult;
    }

    public void setKeyanddifficult(String keyanddifficult) {
        this.keyanddifficult = keyanddifficult;
    }

    public String getTeachingmaterials() {
        return teachingmaterials;
    }

    public void setTeachingmaterials(String teachingmaterials) {
        this.teachingmaterials = teachingmaterials;
    }

    public String getMaincontentsandhoursallocation() {
        return maincontentsandhoursallocation;
    }

    public void setMaincontentsandhoursallocation(String maincontentsandhoursallocation) {
        this.maincontentsandhoursallocation = maincontentsandhoursallocation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseSchEntity that = (CourseSchEntity) o;

        if (Double.compare(that.credit, credit) != 0) return false;
        if (courseid != null ? !courseid.equals(that.courseid) : that.courseid != null) return false;
        if (coursename != null ? !coursename.equals(that.coursename) : that.coursename != null) return false;
        if (theoryhours != null ? !theoryhours.equals(that.theoryhours) : that.theoryhours != null) return false;
        if (testhours != null ? !testhours.equals(that.testhours) : that.testhours != null) return false;
        if (writer != null ? !writer.equals(that.writer) : that.writer != null) return false;
        if (objectivesandrequirements != null ? !objectivesandrequirements.equals(that.objectivesandrequirements) : that.objectivesandrequirements != null)
            return false;
        if (coursesinfo != null ? !coursesinfo.equals(that.coursesinfo) : that.coursesinfo != null) return false;
        if (keyanddifficult != null ? !keyanddifficult.equals(that.keyanddifficult) : that.keyanddifficult != null)
            return false;
        if (teachingmaterials != null ? !teachingmaterials.equals(that.teachingmaterials) : that.teachingmaterials != null)
            return false;
        if (maincontentsandhoursallocation != null ? !maincontentsandhoursallocation.equals(that.maincontentsandhoursallocation) : that.maincontentsandhoursallocation != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = courseid != null ? courseid.hashCode() : 0;
        result = 31 * result + (coursename != null ? coursename.hashCode() : 0);
        result = 31 * result + (theoryhours != null ? theoryhours.hashCode() : 0);
        result = 31 * result + (testhours != null ? testhours.hashCode() : 0);
        temp = Double.doubleToLongBits(credit);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (writer != null ? writer.hashCode() : 0);
        result = 31 * result + (objectivesandrequirements != null ? objectivesandrequirements.hashCode() : 0);
        result = 31 * result + (coursesinfo != null ? coursesinfo.hashCode() : 0);
        result = 31 * result + (keyanddifficult != null ? keyanddifficult.hashCode() : 0);
        result = 31 * result + (teachingmaterials != null ? teachingmaterials.hashCode() : 0);
        result = 31 * result + (maincontentsandhoursallocation != null ? maincontentsandhoursallocation.hashCode() : 0);
        return result;
    }
}
