package mysystem;

public class ElectiveStudentEntity {
    private String idesstucoucla;
    private String studentid;
    private String courseid;
    private String classid;
    private String majortype;
    private String year;
    private Long ispriority;

    public String getIdesstucoucla() {
        return idesstucoucla;
    }

    public void setIdesstucoucla(String idesstucoucla) {
        this.idesstucoucla = idesstucoucla;
    }

    public String getStudentid() {
        return studentid;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }

    public String getMajortype() {
        return majortype;
    }

    public void setMajortype(String majortype) {
        this.majortype = majortype;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Long getIspriority() {
        return ispriority;
    }

    public void setIspriority(Long ispriority) {
        this.ispriority = ispriority;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ElectiveStudentEntity that = (ElectiveStudentEntity) o;

        if (idesstucoucla != that.idesstucoucla) return false;
        if (studentid != null ? !studentid.equals(that.studentid) : that.studentid != null) return false;
        if (courseid != null ? !courseid.equals(that.courseid) : that.courseid != null) return false;
        if (classid != null ? !classid.equals(that.classid) : that.classid != null) return false;
        if (majortype != null ? !majortype.equals(that.majortype) : that.majortype != null) return false;
        if (year != null ? !year.equals(that.year) : that.year != null) return false;
        if (ispriority != null ? !ispriority.equals(that.ispriority) : that.ispriority != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idesstucoucla != null ? idesstucoucla.hashCode() : 0;
        result = 31 * result + (studentid != null ? studentid.hashCode() : 0);
        result = 31 * result + (courseid != null ? courseid.hashCode() : 0);
        result = 31 * result + (classid != null ? classid.hashCode() : 0);
        result = 31 * result + (majortype != null ? majortype.hashCode() : 0);
        result = 31 * result + (year != null ? year.hashCode() : 0);
        result = 31 * result + (ispriority != null ? ispriority.hashCode() : 0);
        return result;
    }
}
