package mysystem;

public class MulChoiceClassEntity {
    private long idcourseclass;
    private String courseid;
    private String classid;
    private String coursename;
    private String multichoiceone;
    private String courseprofessional;

    public long getIdcourseclass() {
        return idcourseclass;
    }

    public void setIdcourseclass(long idcourseclass) {
        this.idcourseclass = idcourseclass;
    }

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public String getMultichoiceone() {
        return multichoiceone;
    }

    public void setMultichoiceone(String multichoiceone) {
        this.multichoiceone = multichoiceone;
    }

    public String getCourseprofessional() {
        return courseprofessional;
    }

    public void setCourseprofessional(String courseprofessional) {
        this.courseprofessional = courseprofessional;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MulChoiceClassEntity that = (MulChoiceClassEntity) o;

        if (idcourseclass != that.idcourseclass) return false;
        if (courseid != null ? !courseid.equals(that.courseid) : that.courseid != null) return false;
        if (classid != null ? !classid.equals(that.classid) : that.classid != null) return false;
        if (coursename != null ? !coursename.equals(that.coursename) : that.coursename != null) return false;
        if (multichoiceone != null ? !multichoiceone.equals(that.multichoiceone) : that.multichoiceone != null)
            return false;
        if (courseprofessional != null ? !courseprofessional.equals(that.courseprofessional) : that.courseprofessional != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (idcourseclass ^ (idcourseclass >>> 32));
        result = 31 * result + (courseid != null ? courseid.hashCode() : 0);
        result = 31 * result + (classid != null ? classid.hashCode() : 0);
        result = 31 * result + (coursename != null ? coursename.hashCode() : 0);
        result = 31 * result + (multichoiceone != null ? multichoiceone.hashCode() : 0);
        result = 31 * result + (courseprofessional != null ? courseprofessional.hashCode() : 0);
        return result;
    }
}
