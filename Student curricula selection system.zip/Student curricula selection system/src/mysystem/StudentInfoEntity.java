package mysystem;

import java.util.Date;

public class StudentInfoEntity {
    private String studentid;
    private String name;
    private String major;
    private String majortype;
    private Date matriculationdate;

    public StudentInfoEntity() {
    }

    public StudentInfoEntity(String studentid, String name, String major, String majortype, Date matriculationdate) {

        this.studentid = studentid;
        this.name = name;
        this.major = major;
        this.majortype = majortype;
        this.matriculationdate = matriculationdate;
    }

    public String getStudentid() {
        return studentid;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getMajortype() {
        return majortype;
    }

    public void setMajortype(String majortype) {
        this.majortype = majortype;
    }

    public Date getMatriculationdate() {
        return matriculationdate;
    }

    public void setMatriculationdate(Date matriculationdate) {
        this.matriculationdate = matriculationdate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StudentInfoEntity that = (StudentInfoEntity) o;

        if (studentid != null ? !studentid.equals(that.studentid) : that.studentid != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (major != null ? !major.equals(that.major) : that.major != null) return false;
        if (majortype != null ? !majortype.equals(that.majortype) : that.majortype != null) return false;
        if (matriculationdate != null ? !matriculationdate.equals(that.matriculationdate) : that.matriculationdate != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = studentid != null ? studentid.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (major != null ? major.hashCode() : 0);
        result = 31 * result + (majortype != null ? majortype.hashCode() : 0);
        result = 31 * result + (matriculationdate != null ? matriculationdate.hashCode() : 0);
        return result;
    }
}
