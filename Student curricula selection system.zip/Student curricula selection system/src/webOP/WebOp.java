package webOP;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

import static sessionFactory.OperateSession.mySession;

public class WebOp {
    public static int getNum(String classID) {
        List electiveStudentEntities = mySession.createQuery("from mysystem.ElectiveStudentEntity where classid='" + classID + "'").list();
        return electiveStudentEntities.size();
    }

    public static double getCredit(String courseName) {
        List listCredit = mySession
                .createQuery("select c.credit " +
                        "from mysystem.CourseSchEntity c " +
                        "where c.coursename='" + courseName + "'").list();
        return (double) listCredit.get(0);
    }

    public static void writeCookie(HttpServletResponse response, String key, String value) {
        writeCookie(response, key, value, -1);
    }

    public static void writeCookie(HttpServletResponse response, String key, String value, int expirse) {
        Cookie newCookie = new Cookie(key, value);
        if (expirse > 0) expirse = expirse * 60;
        newCookie.setPath("/");
        newCookie.setMaxAge(expirse);
        response.addCookie(newCookie);
    }

    public static String readCookie(HttpServletRequest request, String key) {
        String value = "";
        Cookie[] ck = request.getCookies();
        if (ck == null) return "";
        for (Cookie c : ck) {
            if (c.getName().equals(key)) {
                value = c.getValue();
                break;
            }
        }
        return value;
    }

    public static String getStudentName(String studentID) {

        List listCredit = mySession
                .createQuery("select c.name " +
                        "from mysystem.StudentInfoEntity c " +
                        "where c.studentid='" + studentID + "'").list();
        return (String) listCredit.get(0);
    }

}
