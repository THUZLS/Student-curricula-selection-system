package Main;

import sessionFactory.OperateSession;

import java.util.List;

import static sessionFactory.OperateSession.*;

public class Main {
    public static void main(String[] args) throws Exception {
//后台测试

//        startSession();


//        fromCourse.importData().toCourseSch();
//        fromStudent.importData().toStudentInfo();
//        fromCoursePlanAndCourseTimePlan.importData().toTotalClass();

//        courseOperation
//                .selectCourse("SA16225424", 2)
//                .selectCourse("SA16225424", 1)
//                .selectCourse("SA16225418", 2)
//                .selectCourse("SA16225418", 1)
//                .selectCourse("SA16225426", 2)
//                .selectCourse("SA16225426", 1)
//                .selectCourse("SA16225427", 2)
//                .selectCourse("SA16225427", 1);
//                .deleteCourse("SA16225427", 1);
//
//
//        drawCourse.selectClassID("C++1班").randomDraw()
//                .selectClassID("算法1班").randomDraw()
//                .selectClassID("IOS1班").randomDraw();

//        endSession();
    }
}
