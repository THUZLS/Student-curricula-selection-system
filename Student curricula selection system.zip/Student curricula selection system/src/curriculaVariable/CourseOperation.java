package curriculaVariable;

import mysystem.ElectiveStudentEntity;

import java.util.List;

import static sessionFactory.OperateSession.mySession;


public class CourseOperation {
    public CourseOperation selectCourse(String studentID, int idTotalClass) {
        System.out.println("学生(学号:"+studentID+")进行选择课程操作,课程标识符:"+idTotalClass);
        String hql = String.format("select t.courseid,t.classid,t.year from TotalClassEntity t where t.id=%d", idTotalClass);
        List listCourse = mySession.createQuery(hql).list();
        List listStudentMajorType=mySession.createQuery("select s.majortype from StudentInfoEntity s where s.studentid='"+studentID+"'").list();
        Object[] objCourse = (Object[]) listCourse.get(0);
//        Object objStudent = (Object) listStudent.get(0);
        ElectiveStudentEntity eleStu=new ElectiveStudentEntity();
        eleStu.setIdesstucoucla(studentID+"And"+idTotalClass);
        eleStu.setStudentid(studentID);
        eleStu.setCourseid((String)objCourse[0]);
        eleStu.setClassid((String) objCourse[1]);
        eleStu.setMajortype((String) listStudentMajorType.get(0));
        eleStu.setYear((String) objCourse[2]);
        eleStu.setIspriority(0L);
        mySession.saveOrUpdate(eleStu);
        System.out.println(eleStu.getStudentid()+" "+eleStu.getCourseid()+" "+eleStu.getClassid()+" "+eleStu.getMajortype()+" "+ eleStu.getYear()+" "+eleStu.getIspriority());
        System.out.println("选课成功!\n");
        return this;
    }

    public CourseOperation deleteCourse(String studentID, int idTotalClass) {
        System.out.println("学生(学号:"+studentID+")进行删除已选课程操作,课程标识符:"+idTotalClass);
        String hql = String.format("from ElectiveStudentEntity t where t.id='%s'", studentID+"And"+idTotalClass);
        List listES = mySession.createQuery(hql).list();
        for (Object i:listES)
            mySession.delete(i);
        System.out.println("删除成功!\n");
        return this;
    }
}
