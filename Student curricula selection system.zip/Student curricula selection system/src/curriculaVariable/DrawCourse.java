package curriculaVariable;

import mysystem.ElectiveStudentEntity;
import org.hibernate.query.Query;

import java.util.Collections;
import java.util.List;

import static sessionFactory.OperateSession.mySession;


public class DrawCourse {
    private List list;
    private int maxNum;
    private String classID;

    public DrawCourse selectClassID(String classID) {
        this.classID = classID;
        System.out.println("管理员对[" + classID + "]课程进行抽签操作!");
        list = mySession.createQuery("from ElectiveStudentEntity e where e.classid='" + classID + "'").list();
        maxNum = (int) mySession.createQuery("select t.maxnumber from TotalClassEntity t where t.classid='" + classID + "'").list().get(0);
//        Query queryClear = mySession.createQuery("update ElectiveStudentEntity e set e.ispriority=0  where e.classid='" + classID + "'");
//        queryClear.executeUpdate();//立即执行，会使后面的saveOrUpdate失效
//        executeUpdate()方法封装了 事务commit(),而getSession.save()需要手动提交事务；
//        mySession.flush();
//        myTransaction.commit();
//        myTransaction=mySession.beginTransaction();
        return this;
    }
    public DrawCourse randomDraw() {
        System.out.println("抽签方式:随机");
        if (list.size() <= maxNum) {
            Query query = mySession.createQuery("update ElectiveStudentEntity e  set e.ispriority=2  where e.classid='" + classID + "'");
            query.executeUpdate();
            System.out.println("["+classID + "]课程随机抽签处理完毕!");
            System.out.println("报告：实际选课人数:"+list.size()+"   少于等于最大容量:"+maxNum+",全部选中！\n");
        } else {
            List<ElectiveStudentEntity> listCrew = mySession.createQuery(" from ElectiveStudentEntity where classid='" + classID + "'").list();
            Collections.shuffle(listCrew);
            ElectiveStudentEntity es;
            for (int i = 0; i < list.size(); ++i) {
                es = listCrew.get(i);
                if (i < maxNum) es.setIspriority(2L);
                else es.setIspriority(0L);
                mySession.saveOrUpdate(es);
            }
            System.out.println("[" + classID + "]课程随机抽签处理完毕!");
            System.out.println("报告：实际选课人数:" + list.size() +
                    "   课程容量暨选中人数:" + maxNum+"\n");
        }
        return this;
    }
}
