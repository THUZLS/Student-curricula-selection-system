package sessionFactory;

import curriculaVariable.CourseOperation;
import curriculaVariable.DrawCourse;
import databaseOperation.FromCourse;
import databaseOperation.FromCoursePlanAndCourseTimePlan;
import databaseOperation.FromOurSystem;
import databaseOperation.FromStudent;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OperateSession {

    private static SessionFactory SchoolSessionFactory;
    private static SessionFactory MySessionFactory;

    public static Session getSchoolSession() throws HibernateException {
        return SchoolSessionFactory.openSession();
    }

    public static Session getMySession() throws HibernateException {
        return MySessionFactory.openSession();
    }

    public static Session schoolSession;
    public static Session mySession;
    public static Transaction schoolTransaction;
    public static Transaction myTransaction;
    public static FromCourse fromCourse;
    public static FromStudent fromStudent;
    public static FromCoursePlanAndCourseTimePlan fromCoursePlanAndCourseTimePlan;
    public static FromOurSystem fromOurSystem;
    public static CourseOperation courseOperation;
    public static DrawCourse drawCourse;

    public static void startSession() throws HibernateException {
        try {
            Configuration configurationSchool = new Configuration();
            configurationSchool.configure("school.cfg.xml");
            Configuration configurationMy = new Configuration();
            configurationMy.configure("mysystem.cfg.xml");
            SchoolSessionFactory = configurationSchool.buildSessionFactory();
            MySessionFactory = configurationMy.buildSessionFactory();
            schoolSession = getSchoolSession();
            mySession = getMySession();
            schoolTransaction = schoolSession.beginTransaction();
            myTransaction = mySession.beginTransaction();

            fromCourse = new FromCourse();
            fromStudent = new FromStudent();
            fromCoursePlanAndCourseTimePlan = new FromCoursePlanAndCourseTimePlan();
            fromOurSystem=new FromOurSystem();
            courseOperation = new CourseOperation();
            drawCourse = new DrawCourse();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static void endSession() throws HibernateException {
        schoolTransaction.commit();
        myTransaction.commit();
        schoolSession.close();
        mySession.close();
        SchoolSessionFactory.close();
        MySessionFactory.close();
    }
}
